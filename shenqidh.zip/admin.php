<?php
/**
 * Created by 神奇cms.
 * User: 开发作者：神奇  QQ：97302834  官方网站：http://shenqiyu.com.
 * Date: 2020/1/22  16:40
 *'--------------------------------------------------------
 *'这不是一个自由软件！您只能在不用于商业目的的前提下对程序代码进行修改和使用；
 *'不允许对程序代码以任何形式任何目的的再发布。
 *'--------------------------------------------------------
 */
namespace think;


define('APP_PATH', __DIR__ . '/application/');
//define('APP_PATH', __DIR__ . '/application/');
define('SHOUYE_PATH', __DIR__);
// 加载基础文件
require __DIR__ . '/thinkphp/base.php';

// 执行应用并响应
Container::get('app')->path(__DIR__ . '/application')->bind('admin')->run()->send();

<?php
/**
 * Created by 神奇cms.
 * User: 开发作者：神奇  QQ：97302834  官方网站：http://shenqiyu.com.
 * Date: 2020/1/20  14:04
 *'--------------------------------------------------------
 *'这不是一个自由软件！您只能在不用于商业目的的前提下对程序代码进行修改和使用；
 *'不允许对程序代码以任何形式任何目的的再发布。
 *'--------------------------------------------------------
 */

namespace app\admin\controller;
use app\admin\controller\Shenqi;

class Querylist extends Shenqi
{
    public  function index(){
        if(request()->isPost()){
            $data=input('post.');
            $file=SHOUYE_PATH."/config/cj.php";
            $myfile = fopen($file, "w") ;
            fclose($myfile);
            $data = "<?php /*自定义的网站配置文件*/\n return array(\n'sqsetting' =>\n".var_export($data,true)."); ";
            $res=file_put_contents($file,$data);
            if($res)
            {return json(['code'=>1,'msg'=>'编辑成功']);}else
            {return json(['code'=>0,'msg'=>'编辑失败']);}
        }
        $cj=config('cj.sqsetting');
        $this->assign('cj',$cj);
        return view('admin@html/qulist');
    }


}
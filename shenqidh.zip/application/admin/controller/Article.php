<?php
/**
 * Created by 神奇cms.
 * User: 开发作者：神奇  QQ：97302834  官方网站：http://shenqiyu.com.
 * Date: 2020/1/20  13:15
 *'--------------------------------------------------------
 *'这不是一个自由软件！您只能在不用于商业目的的前提下对程序代码进行修改和使用；
 *'不允许对程序代码以任何形式任何目的的再发布。
 *'--------------------------------------------------------
 */

namespace app\admin\controller;
use app\admin\controller\Shenqi;
use think\Db;
use app\common\model\Article as articlemodel;
class Article extends Shenqi
{
    public function index(){
        $res=Db::name('article')->order('addtime desc')->paginate(15);
        $this->assign('list',$res);
        return view('admin@html/article');
    }

    public function addarticle(){
        if(request()->isPost()){
            $param=input('');
            unset($param['LY']);
            unset($param['DZ']);
            unset($param['MM']);
            $addvil=validate('Shenqi');
            if(!$addvil->scene('addar')->check($param)){
               return $this->error($addvil->getError());
            }
            $param['addtime']=strtotime($param['addtime']);
            $armodel=new articlemodel();
            $res=$armodel->allowField(true)->save($param);
            //$res=Db::name('article')->insert($param);
            if($res){
                return $this->success("添加成功");
            }else{
                return $this->error("添加失败");
            }
        }

        $cata=Db::name('cata')->order('sort asc')->select();
        $this->assign('cata',$cata);
        return view('admin@html/addarticle');
    }

    public function editarticle(){
        $aid=input('aid');
        if(request()->isPost()){
            $param=input('');
            $edarvil=validate('Shenqi');
            if(!$edarvil->scene('editar')->check($param)){
                return $this->error($edarvil->getError());
            }
            $armodel=new articlemodel();
            $param['addtime']=strtotime($param['addtime']);
            $res=$armodel->isUpdate(true)->allowField(true)->save($param);
            if($res){
                return $this->success("修改成功");
            }else{
                return $this->error("修改失败");
            }
        }

        $article=Db::name('article')->where('aid',$aid)->find();
        $this->assign('article',$article);
        $cata=Db::name('cata')->order('sort asc')->select();
        $this->assign('cata',$cata);
        return view('admin@html/editarticle');
    }

}
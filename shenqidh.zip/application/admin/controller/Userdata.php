<?php
/**
 * Created by 神奇cms.
 * User: 开发作者：神奇  QQ：97302834  官方网站：http://shenqiyu.com.
 * Date: 2020/1/22  18:27
 *'--------------------------------------------------------
 *'这不是一个自由软件！您只能在不用于商业目的的前提下对程序代码进行修改和使用；
 *'不允许对程序代码以任何形式任何目的的再发布。
 *'--------------------------------------------------------
 */

namespace app\admin\controller;
use app\admin\controller\Shenqi;
use think\Db;

class Userdata extends Shenqi
{
    public function index(){
        $res=Db::name('user')->order('regtime desc')->select();
        $this->assign('list',$res);
        return view('admin@html/user');
    }

    //编辑管理员
    public function editadmin(){
        if(empty(session('uid'))){
            $this->error('请先登录','login/login','',3);
        }
        $uid=session('uid');
        if(request()->isPost()){
            $param=input('post.');
            if($param['sqmima']!==$param['sqmima2']){
                return $this->error("两次密码必须相同");
            }
            $adminvil=validate("Shenqi");
            $rule=['sqname'=>'require|unique:admin'];
            unset($param['sqmima2']);
            $param['sqmima']=md5($param['sqmima']);
            if(!$adminvil->check($param,$rule)){
                return $this->error($adminvil->getError());
            }
            $res=Db::name('admin')->where('id',$uid)->update($param);
            if($res){
                session(null);
                cookie(null);
                return $this->success("成功");
            }else{
                return $this->error("失败");
            }

        }
        $res=Db::name('admin')->where('id',$uid)->find();
        $this->assign('list',$res);
        return view('admin@html/editadmin');
    }

}
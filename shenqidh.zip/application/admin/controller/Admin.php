<?php
/**
 * Created by 神奇cms.
 * User: 开发作者：神奇  QQ：97302834  官方网站：http://shenqiyu.com.
 * Date: 2020/1/6  16:12
 *'--------------------------------------------------------
 *'这不是一个自由软件！您只能在不用于商业目的的前提下对程序代码进行修改和使用；
 *'不允许对程序代码以任何形式任何目的的再发布。
 *'--------------------------------------------------------
 */

namespace app\admin\controller;
use app\admin\controller\Shenqi;
use think\facade\Cache;


class Admin extends Shenqi
{
    public function seo(){
        if(request()->isPost()){
            $data=input('post.');
            //$data['seo']=$param;
            $data = "<?php /*自定义的网站配置文件*/\n return array(\n'seo' =>\n".var_export($data,true)."); ";
            $file=SHOUYE_PATH."/config/seo.php";
            $myfile = fopen($file, "w") ;
            fclose($myfile);
            $res=file_put_contents($file,$data);
            if($res)
            {return json(['code'=>1,'msg'=>'编辑成功']);}else
            {return json(['code'=>0,'msg'=>'编辑失败']);}
        }
        $seo=config('seo.seo');
        $this->assign('seo',$seo);
        return view('admin@html/seo');
    }
    public function cachedel(){
        Cache::clear();
        $this->success("清空完毕..");
    }
    public function index(){
        return view('admin@html/index');
    }
    public function welcome(){
        $version=config('version.sqsetting');
        $this->assign('version',$version);
        return view('admin@html/welcome');
    }
    public function seting(){
        if(request()->isPost()){
            $param=input('post.');
            $res=model('Options')->save( $param,['id' => 1]);
           if($res){
               return json(['code'=>1,'msg'=>'更新成功']);
           }else{
               return json(['code'=>0,'msg'=>'更新失败']);
           }
        }
        $where=[];
        $where['id']=['eq','1'];
        $res=model('Options')->infoData($where);
        $this->assign('list', $res['info']);
        return view('admin@html/seting');
    }

    public function type(){
       /* $param=input('');
        $where=[];
        if(!isset($param['page'])){$param['page']=1;}
        if(!isset($param['limit'])){$param['limit']=10;}
        $order='type_id desc';
        $page=input('page');
        $limit=$param['limit'];
        $res= model('Type')->listData($where,$order,$page,$limit);
        $this->assign('total',$res['total']);
        $this->assign('page',$res['page']);
        $this->assign('limit',$res['limit']);*/
        $res=db('type')->limit(30)->paginate(30);
        $this->assign('list', $res);
        return view('admin@html/type');
    }

    public function edittype(){
        $param=input('');
        if(request()->isPost()){
          $res=model('Type')->allowField(true)->save($param,['type_id' => $param['type_id']]);
          if($res){
              return json(['code'=>1,'msg'=>'更新成功']);
          }else{
              return json(['code'=>0,'msg'=>'更新失败']);
          }
        }
        $res=model('Type')->where('type_id',$param['type_id'])->find();
        $this->assign('list',$res);
        return view('admin@html/edittype');
    }
    public function addtype(){
        $param=input('');
        if(request()->isPost()){
            $param['type_addtime']=time();
            $addtypevalidata=validate('Shenqi');
            if(!$addtypevalidata->scene('addtype')->check($param)){
                return $this->error($addtypevalidata->getError());
            }
            $res=model('Type')->allowField(true)->save($param);
            if($res){
                return json(['code'=>1,'msg'=>'添加成功']);
            }else{
                return json(['code'=>0,'msg'=>'添加失败']);
            }
        }
        return view('admin@html/addtype');
    }

    public function link(){
       /* $param=input('');
        $where=[];
        $order='link_addtime desc';
        $where['link_status']=['eq','1'];
        $page=input('page');
        $limit=1;
        if(!isset($param['page'])){$param['page']=1;}
        if(!isset($param['limit'])){$param['limit']=10;}
        $res=model('Link')->listData($where,$order,$page,$limit);*/
        if(request()->isPost()){
            $keywords=input('keywords');
            $res=model('Link')->where('link_title', 'like', '%'.$keywords.'%')->paginate(30,false,['query'=>request()->param()]);
            $this->assign('list',$res);
            return view('admin@html/link');
        }

        $res=model('Link')->alias('a')->join('type b','b.type_id=a.type_id')->field('a.*,b.type_name')->order('link_addtime desc')->paginate(30);
        //$res=db('type')->limit(30)->paginate(30);
        $this->assign('list',$res);
        return view('admin@html/link');
    }
    public function addlink(){
        $param=input('');
        if(request()->isPost()){
            $addtypevalidata=validate('Shenqi');
            $param['link_addtime']=time();
            $param['link_status']=1;
            if(!$addtypevalidata->scene('addlink')->check($param)){
                return $this->error($addtypevalidata->getError());
            }
            $res=model('Link')->allowField(true)->save($param);
            if($res){
                return json(['code'=>1,'msg'=>'添加成功']);
            }else{
                return json(['code'=>0,'msg'=>'添加失败']);
            }
        }
        $type=model('Type')->select();
        $this->assign('type',$type);
        return view('admin@html/addlink');
    }
    public function editlink(){
        $param=input('');
        if(request()->isPost()){
            $param['link_addtime']=strtotime(date($param['link_addtime']));
            $editlinkvalidata=validate('Shenqi');
            if(!$editlinkvalidata->scene('editlink')->check($param)){
                return $this->error($editlinkvalidata->getError());
            }
            $res=model('Link')->allowField(true)->save($param,['link_id' => $param['link_id']]);
            if($res){
                return json(['code'=>1,'msg'=>'编辑成功']);
            }else{
                return json(['code'=>0,'msg'=>'编辑失败']);
            }
        }
        $type=model('Type')->select();
        $this->assign('type',$type);
        $res=model('Link')->where('link_id',$param['link_id'])->find();
        $this->assign('list',$res);
        return view('admin@html/editlink');
    }
    public function linkshenhe($id,$zid){
           return model('Link')->shenhe($id,$zid);

    }
    public function about(){
        return view('admin@html/about');
    }

    public function del(){
        $param=input('post.');
        $res=model($param['table'])->destroy( $param['id']);
        if($res){
            return json(['code'=>1,'msg'=>'删除成功']);
        }else{
            return json(['code'=>0,'msg'=>'删除失败']);
        }
    }
    public function pldel(){
        $param=input('post.');
        $res=model($param['table'])->destroy( $param['itm']);
        if($res){
            return json(['code'=>1,'msg'=>'删除成功']);
        }else{
            return json(['code'=>0,'msg'=>'删除失败']);
        }
    }
    public function ziliao($tjurl){
        $res=curl_get_file_contents($tjurl);
        $res=get_title_contents($res);
        $res['code']=1;
        $res['msg']="成功";
        //dump($res);
        return json ($res);
    }
}
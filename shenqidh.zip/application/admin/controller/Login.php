<?php
/**
 * Created by 神奇cms.
 * User: 开发作者：神奇  QQ：97302834  官方网站：http://shenqiyu.com.
 * Date: 2020/1/6  16:17
 *'--------------------------------------------------------
 *'这不是一个自由软件！您只能在不用于商业目的的前提下对程序代码进行修改和使用；
 *'不允许对程序代码以任何形式任何目的的再发布。
 *'--------------------------------------------------------
 */

namespace app\admin\controller;


use think\Controller;

class Login extends Controller
{

    public function loginout(){
        session(null);
        cookie(null);
        $this->success("正在退出..",'login/login');
    }
    public function login(){
        if(request()->isPost()){
            $param=input('post.');
            $param['sqname']=$param['username'];
            $param['sqmima']=$param['password'];
            $loginvalidate=validate('Shenqi');
           if(!$loginvalidate->scene('adminlogin')->check($param)){
               return $this->error($loginvalidate->getError());
           }
            $where=[];
            $where['sqname'] = ['eq',$param['username']];
            $where['sqmima'] = ['eq',md5($param['sqmima'])];

            $shenqimodel=model('Admin');
            $res=$shenqimodel->infoData($where);
            if($res['code']==1){
                if($res['info']['status']!==1){
                    return $this->error("管理员账号已冻结");
                }
                $youxiaotm=3600;
                if(isset($param['sq']) && $param['sq']=='1'){
                    session(['expire'=>3600*24*7]);
                    $youxiaotm=3600*24*7;
                }
                $loginip=request()->ip();
                cookie('sqcms','无需解释,cookie设置 防止破解',$youxiaotm);
                cookie('sqtext',$param['username'],$youxiaotm);
                cookie('time',$youxiaotm,$youxiaotm);
                session("uid",$res['info']['id']);
                session("username",$res['info']['sqname']);
                session("admin","admin");
                return $this->success('登录成功','admin/index');
            }else{
                return json($res);
            }

        }
        return view('admin@html/login');
    }
}
<?php
/**
 * Created by 神奇cms.
 * User: 开发作者：神奇  QQ：97302834  官方网站：http://shenqiyu.com.
 * Date: 2020/1/20  12:37
 *'--------------------------------------------------------
 *'这不是一个自由软件！您只能在不用于商业目的的前提下对程序代码进行修改和使用；
 *'不允许对程序代码以任何形式任何目的的再发布。
 *'--------------------------------------------------------
 */

namespace app\admin\controller;
use app\admin\controller\Shenqi;
use think\Db;
use app\common\model\Cata AS catamodel;

class Cata extends Shenqi
{

    public function index(){
        $res=Db::name('cata')->order('sort asc')->select();
        $this->assign('list',$res);
        return view('admin@html/cata');
    }

    public function addcata(){
        if(request()->isPost()){
            $param=input('post.');
            $param['addtime']=time();
            $addvil=validate('Shenqi');
            if(!$addvil->scene('addcata')->check($param)){
                return $this->error($addvil->getError());
            }
            $catam=new catamodel();
            $res=$catam->allowField(true)->save($param);
            if($res){
                return json(['code'=>'1','msg'=>'添加成功']);
            }else{
                $this->error('添加失败');
            }
        }
        return view('admin@html/addcata');

    }

    public function editcata(){
        $cid=input('cid');
        if(request()->isPost()){
            $param=input('post.');
            $addvil=validate('Shenqi');
            if(!$addvil->scene('editcata')->check($param)){
                return $this->error($addvil->getError());
            }
            $catam=new catamodel();
            $res=$catam->isUpdate(true)->allowField(true)->save($param);
            if($res){
                return json(['code'=>'1','msg'=>'编辑成功']);
            }else{
                $this->error('编辑失败');
            }
        }
        $res=Db::name('cata')->where('cid',$cid)->find();
        $this->assign('list',$res);
        return view('admin@html/editcata');
    }
}
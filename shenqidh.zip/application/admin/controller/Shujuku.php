<?php
/**
 * Created by 神奇cms.
 * User: 开发作者：神奇  QQ：97302834  官方网站：http://shenqiyu.com.
 * Date: 2020/1/22  19:35
 *'--------------------------------------------------------
 *'这不是一个自由软件！您只能在不用于商业目的的前提下对程序代码进行修改和使用；
 *'不允许对程序代码以任何形式任何目的的再发布。
 *'--------------------------------------------------------
 */

namespace app\admin\controller;


use app\admin\controller\Shenqi;
use think\Db;

class shujuku extends Shenqi
{
    public function index(){
        return view('admin@html/shujuku');
    }
    public function laiyuan(){
        $sql = ' TRUNCATE TABLE `sq_lailu` ' ; // 清空表数据
        Db::execute($sql);
        return $this->success("清空完毕");
    }

    public function dianchu(){
        $sql = ' TRUNCATE TABLE `sq_dianchu` ' ; // 清空表数据
        Db::execute($sql);
        return $this->success("清空完毕");
    }

}
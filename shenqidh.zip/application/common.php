<?php
// +----------------------------------------------------------------------
// | ThinkPHP [ WE CAN DO IT JUST THINK ]
// +----------------------------------------------------------------------
// | Copyright (c) 2006-2016 http://thinkphp.cn All rights reserved.
// +----------------------------------------------------------------------
// | Licensed ( http://www.apache.org/licenses/LICENSE-2.0 )
// +----------------------------------------------------------------------
// | Author: 流年 <liu21st@gmail.com>
// +----------------------------------------------------------------------


define('SHENQI_PATH', APP_PATH . '/shenqi/');


///提取文章的第一章图片
function getimg($comtent){
    preg_match('/<img.+src=\"?(.+\.(jpg|gif|bmp|bnp|png))\"?.+>/i', $comtent, $matches);
    if(count($matches)!==0){
        return $matches[1];
    }else{
        return '/static/pic/qi.png';
    }
}

function format_date($time){//距离现在时间
    $t=time()-$time;
    $f=array(
        '31536000'=>'年',
        '2592000'=>'个月',
        '604800'=>'星期',
        '86400'=>'天',
        '3600'=>'小时',
        '60'=>'分钟',
        '1'=>'秒'
    );
    foreach ($f as $k=>$v)    {
        if (0 !=$c=floor($t/(int)$k)) {
            return $c.$v.'前';
        }
    }
}

//curl获取资料
function curl_get_file_contents($url,$referer='') {
    static $curl_loops = 0;//避免死了循环必备
    static $curl_max_loops = 3;
    $useragent = "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/56.0.2924.87 Safari/537.36";

    $ch = curl_init();
    curl_setopt($ch,CURLOPT_URL,$url);
    curl_setopt($ch,CURLOPT_HEADER,true);
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 5);
    curl_setopt($ch, CURLOPT_TIMEOUT, 5);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false); //不验证证书
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false); //不验证证书
    curl_setopt($ch,CURLOPT_USERAGENT,$useragent);
    curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
    curl_setopt($ch,CURLOPT_REFERER,$referer);
    $data = curl_exec($ch);
    $ret = $data;
    list($header,$data) = explode("\r\n\r\n",$data,2);
    $http_code = curl_getinfo($ch,CURLINFO_HTTP_CODE);
    $last_url = curl_getinfo($ch,CURLINFO_EFFECTIVE_URL);
    curl_close($ch);
    if ($http_code == 301 || $http_code == 302) {
        $matches = array();
        preg_match('/Location:(.*?)\n/',$header,$matches);
        $url = @parse_url(trim(array_pop($matches)));
        if (!$url) {
            return $data;
        }
        $new_url = $url['scheme'] . '://' . $url['host'] . $url['path'] . (isset($url['query']) ? '?' . $url['query'] : '');
        if ($curl_loops++ >= $curl_max_loops) {
            return false;
        }else {
            $new_url = stripslashes($new_url);
            return curl_get_file_contents($new_url);
        }
    } else {
        list($header,$data) = explode("\r\n\r\n",$ret,2);
        return $data;
    }
}
function get_title_contents($html){
    // 解析 HTML 的 <head> 区段
//  <meta http-equiv="Content-type" content="text/html; charset=utf-8" />
//  <meta content="text/html; charset=gb2312" http-equiv="Content-Type">
    preg_match("/<head.*>(.*)<\/head>/smUi",$html, $htmlHeaders);
    //var_dump($output);die();
    if(!count($htmlHeaders)){
        $title = "无法解析数据中的 <head> 区段";
    }

// 取得 <head> 中 meta 设置的编码格式<meta charset="gb2312">
    if(preg_match('/<meta.*charset=(("){0,1}[a-zA-Z0-9-]*("){0,1})/',$htmlHeaders[1], $results)){
        $charset =  $results[1];
    }else{
        $charset = "None";
    }
    $charset = str_replace('"','',$charset);
// 取得 <title> 中的文字
    if(preg_match("/<title>(.*)<\/title>/Ui",$htmlHeaders[1], $htmlTitles)){
        if(!count($htmlTitles)){
            $title = "无法解析 <title> 的内容";
            exit;
        }
        $ress['title']=$htmlTitles[1];
        // 将  <title> 的文字编码格式转成 UTF-8
        if($charset == "None"){
            $title=$htmlTitles[1];
        }else{
            $title=iconv($charset, "UTF-8", $htmlTitles[1]);
        }
    }
    //$charset['title']=html_entity_decode($title);
    if(preg_match('/<meta name="keywords" content="(.*)"/',$htmlHeaders[1], $results)){
        $ress['keywords']=$results[1];
    }else{
        $ress['keywords']='';
    }

    if(preg_match('/<meta name="description" content="(.*)"/',$htmlHeaders[1], $results)){
        $ress['description']=$results[1];
    }else{
        $ress['description']='';
    }


    return $ress;
    return html_entity_decode($title);
}


// 应用公共文件
function sq_substring($str, $lenth, $start=0)//返回设定字数
{

    $str=strip_tags($str);
    $str=str_replace(PHP_EOL, '', $str);
    $str=str_replace('\n','',$str);
    $str=str_replace('<br>','',$str);
    $str=str_replace('<br/>','',$str);
    $str=str_replace('  ','',$str);
    $str=str_replace(' ','',$str);
    $len = strlen($str);
    $r = array();
    $n = 0;
    $m = 0;

    for($i=0;$i<$len;$i++){
        $x = substr($str, $i, 1);
        $a = base_convert(ord($x), 10, 2);
        $a = substr( '00000000 '.$a, -8);

        if ($n < $start){
            if (substr($a, 0, 1) == 0) {
            }
            else if (substr($a, 0, 3) == 110) {
                $i += 1;
            }
            else if (substr($a, 0, 4) == 1110) {
                $i += 2;
            }
            $n++;
        }
        else{
            if (substr($a, 0, 1) == 0) {
                $r[] = substr($str, $i, 1);
            }else if (substr($a, 0, 3) == 110) {
                $r[] = substr($str, $i, 2);
                $i += 1;
            }else if (substr($a, 0, 4) == 1110) {
                $r[] = substr($str, $i, 3);
                $i += 2;
            }else{
                $r[] = ' ';
            }
            if (++$m >= $lenth){
                break;
            }
        }
    }
    return  join('',$r);
}
<?php
/**
 * Created by 神奇cms.
 * User: 开发作者：神奇  QQ：97302834  官方网站：http://shenqiyu.com.
 * Date: 2020/1/19  16:22
 *'--------------------------------------------------------
 *'这不是一个自由软件！您只能在不用于商业目的的前提下对程序代码进行修改和使用；
 *'不允许对程序代码以任何形式任何目的的再发布。
 *'--------------------------------------------------------
 */

namespace app\index\controller;
use\app\index\controller\Shenqi;
use think\Db;

class Cata extends Shenqi
{
    public function index(){
        $param=input('');
        if(!empty($param['cid'])){
            if(!is_numeric($param['cid'])){
                $this->success("您好像迷路啦！！",'type/index');
            }
        }
        if(empty($param['cid'])){
            $cid=0;
            $seo=config('seo.seo');
            $catainfo=['cid'=>0,'name'=>$seo['catatitle'],'cname'=>'meiyou','keywords'=>$seo['catakeywords'],'description'=>$seo['catadescription'],'sort'=>0,'addtime'=>time()];

        }else{
            $cid=$param['cid'];
            $catainfo=Db::name('cata')->where('cid',$cid)->cache($GLOBALS["config"]["hcsj"])->find();
        }
        $res=Db::name('cata')->cache($GLOBALS["config"]["hcsj"])->select();
        if(!$res){
            $this->success("您好像迷路啦！！",'cata/index');
        }
        $this->assign('catainfo',$catainfo);
        $this->assign('cata',$res);
        $this->assign('cid',$cid);
        $this->assign('shenqidhwz','cata');
        return view('html/cata');
    }
}
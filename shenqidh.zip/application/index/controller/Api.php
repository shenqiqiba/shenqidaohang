<?php
/**
 * Created by 神奇cms.
 * User: 开发作者：神奇  QQ：97302834  官方网站：http://shenqiyu.com.
 * Date: 2020/1/20  22:26
 *'--------------------------------------------------------
 *'这不是一个自由软件！您只能在不用于商业目的的前提下对程序代码进行修改和使用；
 *'不允许对程序代码以任何形式任何目的的再发布。
 *'--------------------------------------------------------
 */

namespace app\index\controller;
use QL\QueryList as qulist;
use think\Controller;
use think\Db;

class Api extends Controller
{

public function gettongji(){
    //开启获取统计
    if(request()->isGet()){
        $end_stime = strtotime(date("Y-m-d"));//今日时间
        $time1 = strtotime(date("Y-m-d", strtotime("-30 day")));;//上月月时间
        //今日
        $to1 = Db::name("dianchu")->where("time > ".$end_stime)->sum("hit");;//点出次数
        $to2 = Db::name("dianchu")->where("time > ".$end_stime)->group("id")->count();;//点出多少个
        //本月
        $to3 = Db::name("dianchu")->where("time > ".$time1)->sum("hit");;//点出次数
        $to4 = Db::name("dianchu")->where("time > ".$time1)->group("id")->count();;//点出多少个
        //来路累计
        $to5 = Db::name("dianchu")->sum("hit");
        $to6 = Db::name("dianchu")->group("id")->count();
        //以上属于来路统计 需要打开统计
        //link_title,link_keywords,link_text,link_url,link_img,link_status,link_hit,link_addtime,link_sort,type_id,link_top,link_intime
        $to7 = Db::name("link")->order("link_hit desc")->limit(10)->field("link_title,link_url,link_hit")->select(); //点击最多排行前10
        $to8 = Db::name("link")->sum("link_hit"); //全站累计点击
        $to9 = Db::name("link")->group("link_id")->count();//全站累计链接数量
        $data=["jinrinum"=>$to1,"jinrito"=>$to2,"benyuenum"=>$to3,"benyueto"=>$to4,"allnum"=>$to5,"allto"=>$to6,"top10"=>$to7,"allhit"=>$to6,"linknum"=>$to9];

        return json($data);
    }
}

    public function cj($pw){
        if($pw!=='123456'){
            return $this->error("入库密码错误");
        }

        $cookie='_uab_collina=156957026553035809452213; ki1e_2132_client_token=1E20C0BB5C121B20DC4D90BA43D03ABC; ki1e_2132_connect_is_bind=1; ki1e_2132_connect_uin=1E20C0BB5C121B20DC4D90BA43D03ABC; ki1e_2132_smile=1D1; ki1e_2132_nofavfid=1; __gads=Test; ki1e_2132_lastviewtime=286318%7C1572014194; ki1e_2132_saltkey=Q0nZRawZ; ki1e_2132_lastvisit=1577420730; ki1e_2132_home_readfeed=1577424385; ki1e_2132_client_created=1578887188; ki1e_2132_auth=cd58%2FocrmzSBnzWyuWeXCqNzgLVf449AlUGByki%2BbadHG5adPCieNXRJQYlsGWIYzleoS%2BSQVdW9fFOO2%2BaOhJuRXkY; ki1e_2132_connect_login=1; ki1e_2132_atarget=1; ki1e_2132_pc_size_c=0; ki1e_2132_connect_last_report_time=2020-01-20; ki1e_2132_ulastactivity=1579504546%7C0; ki1e_2132_lastcheckfeed=286318%7C1579504546; Hm_lvt_da6569f688ba2c32429af00afd9eb8a1=1578887181,1578986753,1579074014,1579504546; amvid=7276209b71bb3b6c535eb13ade371f13; Hm_lpvt_da6569f688ba2c32429af00afd9eb8a1=1579504547; ki1e_2132_lastact=1579505774%09forum.php%09forumdisplay; ki1e_2132_forum_lastvisit=D_15_1579505774';
        //$html=$this->getmyhtml('http://www.zuanke8.com/re.php',$cookie,'','','',TRUE);
        //dump($html);
        // 采集规则
        $rules = [
            //采集id为one这个元素里面的纯文本内容
            'title' => ['.s','text'],
            //采集class为two下面的超链接的链接
            'link' => ['.s','href'],
        ];
        //$html='<div id="threadlist"><div id="x"> 123321111</div></div>';
        $html='http://www.zuanke8.com/forum.php?mod=forumdisplay&fid=15&filter=author&orderby=dateline';
        $qlist=new qulist();
        $hj = $qlist->Query($html,$rules,$cookie,'tbody','UTF-8')->data;
        //dump($hj);
        $newlist=[];

        //红包.现金.线报.电影.在线.优酷.抽奖.成功.撸.福利.jd.好价.女朋友.首发.京东.领.卡.资源.在线.vip.支付宝.微信.VX.爱流量.电影票.翼支付.融e购.善融.钢镚.抽奖.e卡.话费.加油.会员.plus.白条.速度.免费.有货.大水.群发.支付宝.刚需.快递.秒到.新人.优惠券.攻略.教程.抢购.京豆.优惠.0元单.bug.收藏.美团.饿了么.破解.活动
        $keyword=explode('.','红包.现金.0元单.线报.电影.在线.优酷.抽奖.成功.福利.好价.女朋友.收藏.首发.京豆.京东.资源.在线.vip.支付宝.微信.VX.抢购.爱流量.优惠券.电影票.翼支付.攻略.融e购.善融.钢镚.刚需.抽奖.e卡.话费.加油.会员.plus.白条.速度.免费.有货.大水.群发.支付宝.领券.大水.苏宁.必中.秒到.淘宝.天猫.外卖.美团.饿了么.打车.猫眼.淘票票.爱奇艺.腾讯视频.芒果');
        foreach($hj as $k => $v ){
            $tags='';
            foreach($keyword as $key){
                if(strpos($v['title'],$key)!==false){
                    if($tags==''){
                        $tags=$key.',';
                    }else{
                        $tags=$tags.$key.',';
                    }
                    $v['keywords']=$tags;
                    $newlist[]=$v;
                }
            }
        }
        $rules = [
            //采集id为one这个元素里面的纯文本内容
            'content' => ['td','html'],
        ];
        $newlist2=[];
        foreach($newlist as $k => $v ){
            if(strpos($v['link'],'zuanke8.com')==false){
                $v['link']='http://www.zuanke8.com/'.$v['link'];
            }

            $hj = $qlist->Query($v['link'],$rules,$cookie,'.pcb','UTF-8')->data;
            if(count($hj)>=1){
                $linshistr=$hj[0]['content'];
                if(strpos($linshistr,'如题')!==false){$linshistr='';}
                if(strpos($linshistr,'赚小客')!==false){$linshistr='';}
                if(strpos($linshistr,'帮忙')!==false){$linshistr='';}
                if(strpos($linshistr,'什么')!==false){$linshistr='';}
                if(strpos($linshistr,'怎么破')!==false){$linshistr='';}
                if(strpos($linshistr,'怎么办')!==false){$linshistr='';}
                if(strpos($linshistr,'有果')!==false){$linshistr='';}
                if(strpos($linshistr,'果熟')!==false){$linshistr='';}
                if(strpos($linshistr,'哪里有')!==false){$linshistr='';}
                if(strpos($linshistr,'请问')!==false){$linshistr='';}
                if(strpos($linshistr,'rt')!==false){$linshistr='';}
                if(strpos($linshistr,'RT')!==false){$linshistr='';}
                // ;

                $zz='/(<div class="tip tip(.*?)<div class="tip_horn"><\/div>)/is';
                $linshistr=preg_replace($zz,"",$linshistr);
                $search = '/zoomfile="(.*?)"/is';
                $userinfo=[];
                preg_match_all($search,$linshistr,$userinfo);

                foreach($userinfo[1] as $img){
                    $linshistr=preg_replace('/<img id(.*?)>/is','<br><img src="'.$img.'" alt="'.$v['title'].'" ><br>',$linshistr);
                    // $linshistr=preg_replace('/<img id(.*?)>/is',$img,$linshistr);
                }
                $linshistr=preg_replace('/<img src="static(.*?)>/is','',$linshistr);//替换表情
                //<img src="static/image/smiley/cheng/em1036.gif" smilieid="156" border="0" alt="">

                //if(preg_match_all( $search,$linshistr,$userinfo)!==false && count($userinfo)>=3){
                //   $linshistr=preg_replace($userinfo[0],'<img src="'.$userinfo[3].'" alt="'.$v['title'].'">',$linshistr);
                // }

                // $linshistr=preg_replace('</div>',"",$linshistr);
                //$linshistr=preg_replace('/<div (.*?)>/',"",$linshistr);

                //$linshistr=preg_replace('/<(div class="tip.*?)>(.*?)</div>/si',"",$linshistr); //过滤title标签
                // $linshistr=preg_replace('<div class="tip(.*?)</div>',"",$linshistr); //过滤frame标签
                $hj[0]['content']=$linshistr;
            }


            if(count($hj)>=1 && $hj[0]['content']!==''){

                $hj[0]['content']=str_replace('<div class="mbn">',"",$hj[0]['content']);//暂时这样替换 后期看情况 把div正则替换
                $hj[0]['content']=str_replace("</div>","",$hj[0]['content']);
                $hj[0]['content']=str_replace("<ignore_js_op>","",$hj[0]['content']);
                $hj[0]['content']=str_replace("</ignore_js_op>","",$hj[0]['content']);

                $hj[0]['content']=str_replace("<br><br>","",$hj[0]['content']);
                $hj[0]['content']=str_replace("1.特别提醒，询价、询问、交换、合作求代下任何交易相关的帖，都必须发布到赚品交换区; 2.严禁发布时事类，影视版权类帖子; 3.严禁发布他人个人信息以及骚扰类 帖子","",$hj[0]['content']);
                $hj[0]['content']=str_replace("赚客吧","吧友",$hj[0]['content']);
                $hj[0]['content']=str_replace("赚吧","吧友",$hj[0]['content']);
                $hj[0]['content']=str_replace("zuanke8.com/forum-","234555.xyz/cata/",$hj[0]['content']);
                $hj[0]['content']=str_replace("zuanke8.com/search","234555.xyz/cata/",$hj[0]['content']);
                $hj[0]['content']=str_replace("zuanke8.com/forum.php?mod=","234555.xyz/cata/",$hj[0]['content']);
                $hj[0]['content']=str_replace("zuanke8.com/thread-","234555.xyz/cata/",$hj[0]['content']);
                $hj[0]['content']=str_replace(PHP_EOL.PHP_EOL, PHP_EOL, $hj[0]['content']);
                $hj[0]['content']=str_replace(PHP_EOL.PHP_EOL, PHP_EOL, $hj[0]['content']);

                $hj[0]['content'] = stripslashes($hj[0]['content']);//还原转义字符stripslashes


                //if()
                //preg_match_all ("/<b>(.*)<\/b>/U", $userinfo, $pat_array);
                //print_r($pat_array[0]);
                //$hj[0]['content']=str_replace('id="aimg_S2KuS" onclick="zoom(this, this.src, 0, 0, 0)" class="zoom" file=',"src=",$hj[0]['content']);
                //$hj[0]['content']=str_replace('onmouseover="img_onmouseoverfunc(this)" lazyloadthumb="1" border="0" alt=""" class="zoom" file=','alt="'.$v['title'].'"',$hj[0]['content']);

                //$hj[0]['content']=str_replace('zuanke8.com','234555.xyz',$hj[0]['content']);
                if($hj[0]['content']!==''){
                    $v['content']=$hj[0]['content'];
                    $newlist2[]=$v;
                }

            }

        }
        $newlist2=$this->unique_arr($newlist2,'title');
        $jieguo=$this->addar($newlist2,'123456');
        dump($newlist2);
        if($jieguo){
            return '采集成功';
        }else{
            return '采集失败';
        }


    }

    public function addar($content=[],$pw){
        if($pw!=='123456'){
            return $this->error("入库密码错误");
        }
        $addvil=validate('Shenqi');
        $datalist=[];
        foreach($content as $k=>$v){
            if($addvil->scene('addar')->check($v)){
                //开启判断 是否记录来源
                $v['username']='神奇小助手';
                $v['addtime']=time();
                $v['cid']=1;
                $v['status']=1;
                $v['text']=sq_substring($v['content'],50);
                $datalist[]=$v;
            }
        }

        $res=Db::name('article')->insertAll($datalist);

        return $res;



    }
    public function unique_arr($arr, $key){
        $tmp_arr = array();
        foreach($arr as $k => $v)
        {
            if(in_array($v[$key], $tmp_arr))   //搜索$v[$key]是否在$tmp_arr数组中存在，若存在返回true
            {
                unset($arr[$k]); //销毁一个变量  如果$tmp_arr中已存在相同的值就删除该值
            }
            else {
                $tmp_arr[$k] = $v[$key];  //将不同的值放在该数组中保存
            }
        }
        //ksort($arr); //ksort函数对数组进行排序(保留原键值key)  sort为不保留key值
        return $arr;
    }





    public function getmyhtml($url,$cookie){
        $ch = curl_init();
        curl_setopt($ch,CURLOPT_HEADER,0);

        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
        curl_setopt($ch, CURLOPT_AUTOREFERER, true);
        curl_setopt($ch, CURLOPT_REFERER, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_COOKIE, $cookie);
        curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/46.0.2490.71 Safari/537.36');
        curl_setopt($ch, CURLOPT_ENCODING ,'gzip'); //加入gzip解析
        $result = curl_exec($ch);
        curl_close($ch);
        //$result=iconv("GBK","UTF-8",$result);
        //$result= mb_convert_encoding($result, 'UTF-8','GBK');
        $result=mb_convert_encoding($result, 'UTF-8', 'UTF-8,GBK,GB2312,BIG5');//不能用 用了不能匹配到数据
        dump($result);
        return $result;

    }
}
<?php
/**
 * Created by 神奇cms.
 * User: 开发作者：神奇  QQ：97302834  官方网站：http://shenqiyu.com.
 * Date: 2020/1/21  12:59
 *'--------------------------------------------------------
 *'这不是一个自由软件！您只能在不用于商业目的的前提下对程序代码进行修改和使用；
 *'不允许对程序代码以任何形式任何目的的再发布。
 *'--------------------------------------------------------
 */

namespace app\index\controller;
use app\index\controller\Shenqi;
use think\Db;

class User extends Shenqi
{


    public function loginout(){
        session(null);
        cookie(null);
        $this->success("正在退出..",'index/index');
    }

    public function mylink(){
        if(empty(session('uid'))){
            return $this->error("请先登录",'user/login');
        }
        $this->shenqiyz();
        $uid=session('uid');
        $ress=Db::name('shoucang')->where('uid',$uid)->field('lid')->find();

        if(!$ress){
            $this->error("您还没有收藏！！");
        }else{
            $res=explode(",",$ress['lid']);
            $alllid=[];
            foreach($res as $k=>$v){
                if($v!==''){
                    $alllid[]=$v;
                }
            }
            $shoucangmodel=model('Link');
            $links=$shoucangmodel->all($alllid);
        }

        $this->assign('link',$links);
        $this->assign('shenqidhwz','mylink');
        return view('html/user/mylink');
    }

    public function myar(){
        if(empty(session('uid'))){
            return $this->error("请先登录",'user/login');
        }
        $this->shenqiyz();
        $uid=session('uid');
        $ress=Db::name('shoucang')->where('uid',$uid)->field('aid')->find();
        if(!$ress){
            $this->error("您还没有收藏！！");
        }else{
            $res=explode(",",$ress['aid']);
            $allaid=[];
            foreach($res as $k=>$v){
                if($v!==''){
                    $allaid[]=$v;
                }
            }
            $shoucangmodel=model('Article');
            $arlist=$shoucangmodel->all($allaid);
        }

        $this->assign('arlist',$arlist);
        $this->assign('shenqidhwz','myar');
        return view('html/user/myar');
    }
    public function shenqiyz(){
        if(empty(session('uid'))){
            return $this->error("请先登录",'user/login');
        }
        $uid=session('uid');

        $res=Db::name('user')->where('uid',$uid)->cache(3600)->find();
        $this->assign('userinfo',$res);
    }
    public function index(){
        $this->shenqiyz();
        $this->assign('shenqidhwz','user');
        return view('html/user/user');
    }
    public function reg(){
        if(request()->isPost()){
            $param=input('post.');
            if($param['password']!==$param['repassword']){
                $this->error('两次密码不同');
            }
            if(empty($_SESSION['sqcode'])){
                session_start();
            }
            if(strtolower($param['code'])!==$_SESSION['sqcode']){
                return $this->error("验证码错误！");
            }
            unset($param['code']);
            unset($param['repassword']);
            $param['password']=md5($param['password']);
            $regvali=validate('Shenqi');
            $rule=['username|用户名'=>'max:50|require|unique:user','password|密码'=>'max:50|require'];
            if(!$regvali->check($param,$rule)) {
                return $this->error($regvali->getError());
            }
            $param['regip']=request()->ip();
            $param['regtime']=time();

            $res=Db::name('user')->insert($param);
            if($res){
                return $this->success("注册成功");
            }else{
                return $this->error("注册失败");
            }


        }
        $this->assign('shenqidhwz','user');
        return view('html/user/reg');
    }
    public function login(){
        if(request()->isPost()){
            $param=input('post.');
            $loginvali=validate('Shenqi');
            $youxiaotm=3600*24;
            if(!empty($param['jizhuwo'])){
                $youxiaotm=3600*24*7;
            }

            if(empty($_SESSION['sqcode'])){
                session_start();
            }
            if(strtolower($param['code'])!==$_SESSION['sqcode']){
                return $this->error("验证码错误！");
            }
            if(!$loginvali->scene('login')->check($param)){
                return $this->error($loginvali->getError());
            }
            $res=Db::name('user')->where('username',$param['username'])->find();
            if($res){
                if($res['password']==md5($param['password'])){
                    $loginip=request()->ip();
                    cookie('sqcms','无需解释,cookie设置 防止破解',$youxiaotm);
                    cookie('uid',$res['uid'],$youxiaotm);
                    cookie('sqtext',$param['username'],$youxiaotm);
                    cookie('time',$youxiaotm,$youxiaotm);
                    session("uid",$res['uid']);
                    session("username",$res['username']);
                    session("admin","index");
                    Db::name('user')->where('uid',$res['uid'])->data(['loginip' =>$loginip]) ->update();
                    return $this->success("登录成功!!",'user/index');
                }else{
                    return $this->error("用户名或者密码错误！");
                }
            }else{
                return $this->error("用户名或者密码错误！");
            }

        }
        $this->assign('shenqidhwz','user');
        return view('html/user/login');
    }

}
<?php
/**
 * Created by 神奇cms.
 * User: 开发作者：神奇  QQ：97302834  官方网站：http://shenqiyu.com.
 * Date: 2020/1/20  11:19
 *'--------------------------------------------------------
 *'这不是一个自由软件！您只能在不用于商业目的的前提下对程序代码进行修改和使用；
 *'不允许对程序代码以任何形式任何目的的再发布。
 *'--------------------------------------------------------
 */

namespace app\index\controller;
use app\index\controller\Shenqi;
use think\Db;

class Search extends Shenqi
{
    public function index(){
        $key=input('searchkeywords');
        $type=input('type');
        if(empty(input('searchkeywords'))){
            $this->error('非法操作','index/index');
        }
        if($key==''){
            $this->error('请输入搜索内容','index/index');
        }

        if(!is_numeric($type)){

            $this->error('非法操作','index/index');
        }
        $key=sq_substring($key,50);

        //session('searchtime',time()+1000);
        if($type==1){
            $res=Db::name('article')->where('a.status=1')->where('a.title','like','%'.$key.'%')->whereTime('a.addtime', 'year')->alias('a')->join('cata b','b.cid=a.cid')->field('a.aid,a.title,a.cid,b.cid,b.name,a.text,a.addtime,a.hit')->cache($GLOBALS["config"]["hcsj"])->paginate(10,false,['query'=>request()->param()]);
        }

        if($type==2){
            $res=Db::name('link')->where('a.link_status=1')->where('a.link_title','like','%'.$key.'%')->alias('a')->join('type b','b.type_id=a.type_id')->field('a.*,b.type_id,b.type_name')->cache($GLOBALS["config"]["hcsj"])->paginate(10,false,['query'=>request()->param()]);
        }
        if(time() - cookie('shenqiseartime')<2){
            $this->error('速度过快,2秒后再次操作');
        }

        cookie('shenqiseartime',time());
        //$res=preg_replace($key, "<font color='#FF0000'>".$key."</font>", $res);
        $this->assign('type',$type);
        $this->assign('searchkeywords',$key);
        $this->assign('shenqidhwz','cata');
        $this->assign('list',$res);
        return view('html/search');

    }

    public function tags(){

        $artag=input('artag');
        $lktag=input('lktag');
        if($lktag=='' && $artag==''){
            $this->error('请勿瞎搞2020','index/index');
        }
        if(isset($artag)){
            $type='1';
            $tag=$artag;
            $res=Db::name('article')->where('a.status=1')->where('a.keywords','like','%'.$artag.'%')->whereTime('a.addtime', 'year')->alias('a')->join('cata b','b.cid=a.cid')->field('a.aid,a.title,a.cid,b.cid,b.name,a.text,a.addtime,a.hit')->cache($GLOBALS["config"]["hcsj"])->paginate(10,false,['query'=>request()->param()]);

        }
        if(isset($lktag)){
            $type='2';
            $tag=$lktag;
            $res=Db::name('link')->where('a.link_status=1')->where('a.link_keywords','like','%'.$lktag.'%')->alias('a')->join('type b','b.type_id=a.type_id')->field('a.*,b.type_id,b.type_name')->cache($GLOBALS["config"]["hcsj"])->paginate(10,false,['query'=>request()->param()]);

        }
        if(time() - cookie('shenqiseartime')<2){
            $this->error('速度过快,2秒后再次操作');
        }
        cookie('shenqiseartime',time());
        $this->assign('tag',$tag);
        $this->assign('type',$type);
        $this->assign('list',$res);
        $this->assign('shenqidhwz','index');
        return view('html/tags');
    }

}
<?php
/**
 * Created by 神奇cms.
 * User: 开发作者：神奇  QQ：97302834  官方网站：http://shenqiyu.com.
 * Date: 2020/1/17  20:42
 *'--------------------------------------------------------
 *'这不是一个自由软件！您只能在不用于商业目的的前提下对程序代码进行修改和使用；
 *'不允许对程序代码以任何形式任何目的的再发布。
 *'--------------------------------------------------------
 */

namespace app\index\controller;
use app\index\controller\Shenqi;
use think\Db;

class Link extends Shenqi
{
    public function shoucang($lid){
        if(empty($lid)){
            return $this->error("你好像麋鹿啦101");
        }
        if(!is_numeric($lid)){
            return $this->error("你好像麋鹿啦102");
        }
        if(empty(session('uid'))){
            return $this->error("请先登录",'user/login');
        }
        $uid=session('uid');
        $res=Db::name('shoucang')->where('uid',$uid)->field('lid')->find();


        if($res){
            if(strpos($res['lid'],",".$lid.",")!==false){
                return $this->error("您已经收藏这个链接啦！");
            }
            if($res['lid']==''){
                $lid=','.$lid.',';
            }else{
                $lid=$res['lid'].$lid.',';
            }
            $ss=Db::name('shoucang')->where('uid', $uid)->update(['lid' =>$lid]);
        }else{
            $lid=','.$lid.',';
            $ss=Db::name('shoucang')->insert(['lid' =>$lid,'uid'=>$uid]);
        }
        //http://127.0.0.3/index.php/index/link/shoucang/lid/5.html

        if($ss){
            return $this->success("收藏成功");
        }else{
            return $this->error("收藏失败");
        }
    }
    public function index(){
        $lid=input('lid');
        if(empty($lid)){
           $this->success("您好像迷路啦！！",'type/index');
        }
        if(!is_numeric($lid)){
            $this->success("您好像迷路啦！！",'type/index');
        }

        $links=Db::name('Link')->where('a.link_id',$lid)->alias('a')->join('type b','b.type_id=a.type_id')->field('a.*,b.type_name')->cache($GLOBALS['config']['hcsj'])->find();
        if(!$links){
            $this->success("您好像迷路啦！！");
        }
        $keywords2=explode(',',$links['link_keywords']);
        $keywords=[];
        foreach($keywords2 as $k=>$v){
            if($v!==''){
                $keywords[] =$v;
            }
        }

        $this->assign('keywords',$keywords);
        $this->assign('links',$links);
        $this->assign('shenqidhwz','link');
        return view('html/link');

    }

    public function url(){
        $lid=input('lid');
        if(empty($lid)){
            $this->success("您好像迷路啦！！");
        }
        if(!is_numeric($lid)){
            $this->success("您好像迷路啦！！",'type/index');
        }

        $links=Db::name('Link')->field('link_url')->where('link_id',$lid)->cache($GLOBALS['config']['hcsj'])->find();

        if(!$links){
            $this->success("您好像迷路啦！！");
        }
        if($GLOBALS['config']['dianchu']==1){
            $time=strtotime(date('Y-m-d'));
            $ss=Db::name('dianchu')->where('time',$time)->where('link_id',$lid)->find();
            if($ss){
                Db::name('dianchu')->where('time',$time)->where('link_id',$lid)->setInc('hit',1);
            }else{
                $data['link_id']=$lid;
                $data['hit']=1;
                $data['time']=$time;
                db('dianchu')->insert($data);
            }

        }
        Db::name('link')->where('link_id', $lid)->setInc('link_hit', 1);
        $this->assign('shenqidhwz','url');
        return "<script type='text/javascript'>window.location.href='".$links['link_url']."';</script>";

    }

    public function shoulu(){
        if(request()->isPost()){
            $param=input('post.');
            //url=&img=&fenlei=%E5%BD%B1%E8%A7%86&keywords=&text=&code=
            //url=%E5%A4%A7%E5%B9%85%E5%BA%A6&img=&fenlei=5&keywords=%E6%98%AF%E5%AF%B9%E6%96%B9%E7%AD%94%E5%A4%8D&text=&code=
            if(empty($_SESSION['sqcode'])){
                session_start();
            }
            if(strtolower($param['code'])==$_SESSION['sqcode']){
                //strtolower转化为小写的函数
                $data['link_title']=$param['title'];
                $data['link_url']=$param['url'];
                $data['link_img']=$param['img'];
                $data['type_id']=$param['fenlei'];
                $data['link_keywords']=$param['keywords'];
                $data['link_text']=$param['text'];
                $data['link_status']=0;
                $data['link_addtime']=time();
                $shouluvalidata=validate('Shenqi');
                if(!$shouluvalidata->scene('shoulu')->check($data)){
                    return $this->error($shouluvalidata->getError());
                }
                $res=model('Link')->save($data);
                if($res){
                    return $this->success("添加成功");
                }else{
                    return $this->error("添加失败");
                }
            }else{
                return $this->error("验证码错误".strtolower($_SESSION['sqcode']));
            }
        }
        $this->assign('shenqidhwz','shoulu');
        return view('html/shoulu');
    }

    public function top(){
        //总点出排行榜
        $outtop1=Db::name('link')->field('link_id,link_title,link_hit')->order('link_hit desc')->limit(10)->cache(3600)->select();
        $this->assign('outtop1',$outtop1);
        //今日点出排行
        $time=strtotime(date('Y-m-d'));
        $outtop2=Db::name('dianchu')->where('time',$time)->alias('a')->join('link b ','b.link_id= a.link_id')->field('b.link_id,b.link_title,a.hit')->order('a.hit desc')->limit(10)->cache(3600)->select();
        foreach($outtop2 as $k => $v){
            $v['link_hit']=$v['hit'];
            $outtop2[$k]=$v;
        }
        $this->assign('outtop2',$outtop2);

        //总点入排行
        $intop1=Db::name('lailu')->where('a.link_id != ""')->field('a.*,b.link_title,sum(hit)')->group('a.link_id')->alias('a')->join('link b','b.link_id=a.link_id')->limit(10)->cache(3600)->select();
        foreach($intop1 as $k => $v){
            $v['link_hit']=$v['sum(hit)'];
            $intop1[$k]=$v;
        }
        //进行数组圣虚排序
        $intop1=$this->array_sequence($intop1,'link_hit');
        $this->assign('intop1',$intop1);


        //今日点入排行
        $intop2=Db::name('lailu')->where('time',$time)->where('a.link_id != ""')->alias('a')->join('link b','b.link_id=a.link_id')->field('a.*,b.link_title')->order('hit desc')->limit(10)->cache(3600)->select();
        foreach($intop2 as $k => $v){
            $v['link_hit']=$v['hit'];
            $intop2[$k]=$v;
        }
        $this->assign('intop2',$intop2);

        //24小时热门线报
        $time = time();//现在时间
        $time1 = strtotime('-1 days');//24小时

        $artop1=Db::name('article')->where("addtime > {$time1}")->field('title,hit,aid')->order('hit desc')->cache(3600)->limit(10)->select();
        $this->assign('artop1',$artop1);
        //48小时热门线报
        $time = time();//现在时间
        $time2 = strtotime('-2 days');//48小时
        $artop2=Db::name('article')->where("addtime > {$time2}")->field('title,hit,aid')->order('hit desc')->cache(3600)->limit(10)->select();
        $this->assign('artop2',$artop2);

        $this->assign('shenqidhwz','top');
        return view('html/top');
    }
    /**
     * 二维数组根据字段进行排序
     * params array $array 需要排序的数组
     * params string $field 排序的字段
     * params string $sort 排序顺序标志 SORT_DESC 降序；SORT_ASC 升序
     */
    public static function array_sequence($data = [], $field, $sort = 'SORT_DESC')
    {
        $arrSort = [];
        foreach ($data as $id => $row) {
            foreach ($row as $key => $value) {
                $arrSort[$key][$id] = $value;
            }
        }
        if(count($arrSort)>0){
            array_multisort($arrSort[$field], constant($sort), $data);
        }

        return $data;
    }

}
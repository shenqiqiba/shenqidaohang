<?php
/**
 * Created by 神奇cms.
 * User: 开发作者：神奇  QQ：97302834  官方网站：http://shenqiyu.com.
 * Date: 2020/1/17  19:59
 *'--------------------------------------------------------
 *'这不是一个自由软件！您只能在不用于商业目的的前提下对程序代码进行修改和使用；
 *'不允许对程序代码以任何形式任何目的的再发布。
 *'--------------------------------------------------------
 */

namespace app\index\controller;


use app\index\controller\Shenqi;
use think\Db;
class Type extends Shenqi
{
    public function index(){
        $param=input('');
        if(!empty($param['tid'])){
            if(!is_numeric($param['tid'])){
                $this->success("您好像迷路啦！！",'type/index');
            }
            $typeinfo=Db::name('type')->where('type_id',$param['tid'])->cache($GLOBALS["config"]['hcsj'])->find();
            $this->assign('typeinfo',$typeinfo);
            $this->assign('typeid',$param['tid']);
            }else{
                $this->assign('typeid',0);
                $seo=config('seo.seo');
                $typeinfo=['type_id'=>0,'type_name'=>$seo['typetitle'],'type_keywords'=>$seo['typekeywords'],'type_description'=>$seo['typedescription'],'type_status'=>1,'type_addtime'=>time(),'type_sort'=>1,'type_enname'=>'daquan'];
                $this->assign('typeinfo',$typeinfo);
            }
        $res=Db::name('type')->cache($GLOBALS["config"]["hcsj"])->select();
        if(!$res){
            $this->success("您好像迷路啦！！",'type/index');
        }
        $this->assign('type',$res);
        $this->assign('shenqidhwz','type');
        return view('html/type');
    }
}
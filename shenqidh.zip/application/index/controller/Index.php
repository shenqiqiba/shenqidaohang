<?php
namespace app\index\controller;
use app\index\controller\Shenqi;
use think\Db;

class Index extends Shenqi
{
    public function index()
    {



        //来源统计
        //是否开启统计


        if($GLOBALS["config"]['laiyuan']==1){
            $time=strtotime(date('Y-m-d'));
            if(empty(cookie('welcome'))){
                cookie('welcome',$time,3600*24);
                $file=SHENQI_PATH.date('Ymd').'ip.txt';
                $ip=request()->ip();
                if(!file_exists($file)){
                    //打开 写入 关闭 PHP_EOL为常量 换行符
                    $myfile = fopen($file, "w") ;
                    fwrite($myfile,'==神奇提示你这个是IP记录=='.PHP_EOL);
                    fclose($myfile);
                }

                $res=file_get_contents($file);
                //删除昨日IP记录
                $oldfile=SHENQI_PATH.date('Ymd',strtotime("-1 day")).'ip.txt';
                //删除文件 加上@忽略错误
                @unlink($oldfile);
                if(strpos($res,$ip)!==false){

                }else{
                    $headlailu=request()->header();
                    if(!empty($headlailu['referer'])){
                        $refererUrl =parse_url($headlailu['referer']);
                        $host=$refererUrl['host'];
                        $data['host']=$host;
                        $data['link_url']=$headlailu['referer'];
                        $data['time']=$time;

                        $myfile = fopen($file, "a+") ;
                        $txt=$ip.PHP_EOL;
                        fwrite($myfile, $txt);
                        fclose($myfile);



                        $yz=validate('Shenqi');
                        if($yz->check($data,[ 'link_url|链接' =>  'url|require'])){
                            $res=Db::name('link')->where('link_url','http://'.$host)->whereOr('link_url','https://'.$host)->cache(3600)->find();
                            if($res){
                                $data['link_id']=$res['link_id'];
                                Db::name('link')->where('link_id',$res['link_id'])->update(['link_intime'=>time()]);
                                if($GLOBALS["config"]['laiyuanshenhe']==1 && $res['link_status']==0){
                                    Db::name('link')->where('link_id',$res['link_id'])->update(['link_status'=>1]);
                                }
                            }

                            $ress=Db::name('lailu')->where('host',$host)->where('time',$time)->find();
                            if($ress){
                                $data['hit']=$ress['hit']+1;
                                model('Lailu')->allowField(true)->isUpdate(true)->save($data,['id' => $ress['id']]);
                            }else{

                                //不存在也插入
                                if($GLOBALS["config"]['laiyuan1']==1){
                                    $data['hit']=1;
                                    model('Lailu')->allowField(true)->isUpdate(false)->save($data);
                                }
                            }
                        }
                    }
                }




            }
        }

        $this->assign('shenqidhwz','index');
        return view('html/index');
    }


}

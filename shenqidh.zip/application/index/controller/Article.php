<?php
/**
 * Created by 神奇cms.
 * User: 开发作者：神奇  QQ：97302834  官方网站：http://shenqiyu.com.
 * Date: 2020/1/19  16:09
 *'--------------------------------------------------------
 *'这不是一个自由软件！您只能在不用于商业目的的前提下对程序代码进行修改和使用；
 *'不允许对程序代码以任何形式任何目的的再发布。
 *'--------------------------------------------------------
 */

namespace app\index\controller;
use app\index\controller\Shenqi;
use think\Db;
use think\facade\Url;

class Article extends Shenqi
{
    public function zan($aid){
        if(empty($aid)){
            return $this->error("你好像麋鹿啦");
        }
        if(!is_numeric($aid)){
            return $this->error("你好像麋鹿啦");
        }
        $ss=Db::name('article')->where('aid', $aid)->setInc('zan',1);
        if($ss){
            return $this->success("点赞成功！");
        }else{
            return $this->error("点赞失败！");
        }
    }
    public function shoucang($aid){
        if(empty($aid)){
            return $this->error("你好像麋鹿啦");
        }
        if(!is_numeric($aid)){
            return $this->error("你好像麋鹿啦");
        }
        if(empty(session('uid'))){
            return $this->error("请先登录",'user/login');
        }
        $uid=session('uid');
        $res=Db::name('shoucang')->where('uid',$uid)->field('aid')->find();
        if($res){
            if(strpos($res['aid'],",".$aid.",")!==false){
                return $this->error("您已经收藏过这篇文章啦！");
            }
            if($res['aid']==''){
                $aid=','.$aid.',';
            }else{
                $aid=$res['aid'].$aid.',';
            }
            $ss=Db::name('shoucang')->where('uid', $uid)->update(['aid' =>$aid]);
        }else{
            $aid=','.$aid.',';
            $ss=Db::name('shoucang')->insert(['aid' =>$aid,'uid'=>$uid]);
        }
        //http://127.0.0.3/index.php/index/article/shoucang/aid/5.html

        if($ss){
            return $this->success("收藏成功");
        }else{
            return $this->error("收藏失败");
        }
    }

    public function index(){
        $aid=input('aid');
        if(empty($aid)){
            $this->success("您好像迷路啦！！",'cata/index');
        }
        if(!is_numeric($aid)){
            $this->success("您好像迷路啦！！",'cata/index');
        }

        $res=Db::name('article')->where('a.status=1')->where('a.aid',$aid)->alias('a')->join('cata b','b.cid=a.cid')->field('a.*,b.cid,b.name')->cache($GLOBALS["config"]["hcsj"])->find();
        if(!$res){
            $this->success("您好像迷路啦！！",'cata/index');
        }
        $keywords2=explode(',',$res['keywords']);
        $keywords=[];
        foreach($keywords2 as $k=>$v){
                if($v!==''){
                    $keywords[] =$v;
                }
        }
        $likear=[];
        if(count($keywords)>=1){
            $tags=$keywords[0];
            $likear=Db::name('article')->where('a.status=1')->where('a.keywords','like','%'.$tags.'%')->alias('a')->join('cata b','b.cid=a.cid')->field('a.aid,a.title,a.cid,b.cid,b.name,a.text,a.addtime,a.hit')->limit(5)->cache($GLOBALS["config"]["hcsj"])->select();
        }
        $this->assign('likear',$likear);
        $this->assign('keywords',$keywords);
        $this->assign('article',$res);
        $this->assign('shenqidhwz','cata');
        return view('html/article');
    }
}
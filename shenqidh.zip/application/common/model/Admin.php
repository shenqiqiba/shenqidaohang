<?php
/**
 * Created by 神奇cms.
 * User: 开发作者：神奇  QQ：97302834  官方网站：http://shenqiyu.com.
 * Date: 2020/1/6  16:17
 *'--------------------------------------------------------
 *'这不是一个自由软件！您只能在不用于商业目的的前提下对程序代码进行修改和使用；
 *'不允许对程序代码以任何形式任何目的的再发布。
 *'--------------------------------------------------------
 */

namespace app\common\model;


use think\Db;
use think\Model;

class Admin extends Model
{
    public function infoData($where,$field='*')
    {
        if(empty($where) || !is_array($where)){
            return ['code'=>1001,'msg'=>'参数错误'];
        }
        $info = $this->field($field)->where($where)->find();

        if(empty($info)){
            return ['code'=>1002,'msg'=>'账号或者密码错误'];
        }
        $info = $info->toArray();
        return ['code'=>1,'msg'=>'获取成功','info'=>$info];
    }

    public function getlist($sq,$__cid__){
        if(!is_array($sq)){
            $sq = json_decode($sq,true);
        }
        //{"table":"cata","id":"vo","key":"k","where":"","order":"sort desc","page":"false","limit":"10","cid":""field}
        $where='';
        //链接操作
        if($sq['table']=='link'){
            if($sq['where']!==''){
                $where=$sq['where'].' AND link_status=1';
            }else{
                $where='link_status=1';
            }
            if($__cid__!==0 && $__cid__!==''){
                $where=$where." AND type_id=".$__cid__;
            }
        }
        //友联分类操作
        if($sq['table']=='type'){
            if($sq['where']!==''){
                $where=$sq['where'];
            }
            if($__cid__!==0 && $__cid__!==''){
                $where=$where." AND type_id=".$__cid__;
            }
        }
        //文章分类
        if($sq['table']=='cata'){
            if($sq['where']!==''){
                $where=$sq['where'];
            }
        }
        //文章操作
        if($sq['table']=='article'){
            if($sq['where']!==''){
                $where=$sq['where'].' AND status=1';
            }else{
                $where='status=1';
            }
            if($__cid__!==0 && $__cid__!==''){
                $where=$where." AND cid=".$__cid__;
            }
        }
        //设定缓存时间
        if($sq['hcsj']==0){
            $hcsj=$GLOBALS["config"]["hcsj"];
        }else{
            $hcsj=$sq['hcsj'];
        }
        if($sq['table']=='article'){
            $where=str_replace("cid","a.cid",$where);
            if($sq['page']){
                $res=Db::name($sq['table'])->where($where)->alias('a')->join('cata b','b.cid= a.cid')->field('a.*,b.cid,b.name')->order($sq['order'])->cache($hcsj)->paginate($sq['limit']);
				//$res=Db::name($sq['table'])->where($where)->order($sq['order'])->cache($hcsj)->paginate($sq['limit']);
            }else{

                $res=Db::name($sq['table'])->where($where)->alias('a')->join('cata b ','b.cid = a.cid')->field('a.*,b.cid,b.name')->order($sq['order'])->limit($sq['limit'])->cache($hcsj)->select();

            }
        }else{
            if($sq['page']){
                $res=Db::name($sq['table'])->where($where)->order($sq['order'])->cache($hcsj)->paginate($sq['limit']);
            }else{
                $res=Db::name($sq['table'])->where($where)->limit($sq['limit'])->order($sq['order'])->cache($hcsj)->select();
            }
        }



        //dump($sq);
        //dump($__cid__);
        //dump($sq['table']);
        //dump($where);
        //dump($res);
       // die;
        return $res;


    }

}
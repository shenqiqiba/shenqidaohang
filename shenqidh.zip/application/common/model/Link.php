<?php
/**
 * Created by 神奇cms.
 * User: 开发作者：神奇  QQ：97302834  官方网站：http://shenqiyu.com.
 * Date: 2020/1/14  18:09
 *'--------------------------------------------------------
 *'这不是一个自由软件！您只能在不用于商业目的的前提下对程序代码进行修改和使用；
 *'不允许对程序代码以任何形式任何目的的再发布。
 *'--------------------------------------------------------
 */

namespace app\common\model;


use think\Model;

class Link extends Model
{
    protected $pk = 'link_id';

    public function listData($where, $order, $page, $limit = 20)
    {
        $total = $this->where($where)->count();
        $list = $this->where($where)->order($order)->page($page)->limit($limit)->select();
        return ['code' => 1, 'msg' => '数据列表', 'page' => $page, 'pagecount' => ceil($total / $limit), 'limit' => $limit, 'total' => $total, 'list' => $list];
    }

    public function shenhe($id, $zid)
    {

        if ($zid == 1) {
            //已经审核 改成未审核
            $res=$this->save(['link_status'  => '0'],['link_id' => $id]);
        }else{
            $res=$this->save(['link_status'  => '1'],['link_id' => $id]);
        }
        if($res){
            return json(['code'=>1,'msg'=>'更新成功']);
        }else{
            return json(['code'=>1,'msg'=>'更新失败']);
        }
    }


}
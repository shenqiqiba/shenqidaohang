<?php
/**
 * Created by 神奇cms.
 * User: 开发作者：神奇  QQ：97302834  官方网站：http://shenqiyu.com.
 * Date: 2019/12/30  19:44
 *'--------------------------------------------------------
 *'这不是一个自由软件！您只能在不用于商业目的的前提下对程序代码进行修改和使用；
 *'不允许对程序代码以任何形式任何目的的再发布。
 *'--------------------------------------------------------
 */
namespace app\common\validate;

use think\Validate;

class Shenqi extends Validate
{
    protected $rule = [
        'sqname|用户名'  =>  'require|max:25',
        'sqmima|密码' =>  'require',
        'type_name|分类名称' =>  'require|unique:type',
        'type_enname|分类别名' =>  'max:25|unique:type',
        'link_title|链接名称' =>  'max:25|unique:link',
        'link_url|链接' =>  'url|unique:link',
        'type_id|分类ID' =>  'require|number|max:25',
        'name|分类名'=>'require|unique:cata',
        'cname|分类别名'=>'max:25|unique:cata',
        'title|标题'=>'require|unique:article',
        'tname|标题别名'=>'max:25|unique:article',

        'username|用户名'=>'max:50|require',
        'password|密码'=>'max:50|require',
    ];

    protected $message  =   [
        'link_url.url' => '链接必须是url',
        'type_name.require' => '名称必须',
        'type_name.unique' => '名称已存在',
        'type_enname.max' => '别名不能超过25',
        'type_enname.unique' => '别名已存在',
        'name.require' => '名称必须',
        'name.max'     => '名称最多不能超过25个字符',
        'age.number'   => '年龄必须是数字',
        'age.between'  => '年龄只能在1-120之间',
        'email'        => '邮箱格式错误',
    ];

    protected $scene = [
       // 'reg'=>['username2','password'],
        'login'=>['username','password'],
        'editar'=>['title','tname'],
        'addar'=>['title','tname'],
        'editcata'=>['name','cname'],
        'addcata'=>['name','cname'],
        'editlink'=>['link_title','link_url'],
        'adminlogin'=>['sqname','sqmima'],
        'addtype'=>['type_name','type_enname'],
        'addlink'=>['link_title','link_url'],
        'shoulu'=>['link_title','link_url','type_id'],
        'edit'  =>  ['name','age'],
    ];


}
<?php
namespace app\common\taglib;
use think\template\TagLib;
use think\Db;
class Shenqi extends TagLib{



    /**
     * 定义标签列表
     */

    protected $tags   =  [
        // 标签定义： attr 属性列表 close 是否闭合（0 或者1 默认1） alias 标签别名 level 嵌套层次
        // volist 这种叫非闭合标签用1   例如网站配置为闭合为0
        'close'     => ['attr' => 'time,format', 'close' => 0], //闭合标签，默认为不闭合
        'test'      => ['attr' => 'num', 'close' => 0],


        'list2'  => ['attr' => 'table,id,key,where,limit,order,page,cid', 'close' => 1],
        'list'  => ['attr' => 'table,id,key,where,limit,order,page,field,cid', 'close' => 1],
        //num数量 key顺序 by排序 id解析数组名 page真假  where为条件 typeid
    ];


    /**
     * 【注意1】：标签是有缓存的 所以测试时需要删除runtime
     * 【注意2】：$parse 里面的相当于运行php 不知道为啥要这么写
     */
    public function tagTest($tag)
    {
        return '11111111';
    }

    

    public function tagClose($tag)
    {
        $format = empty($tag['format']) ? 'Y-m-d H:i:s' : $tag['format'];
        $time = empty($tag['time']) ? time() : $tag['time'];
        $parse = '<?php ';
        $parse .= 'echo date("' . $format . '",' . $time . ');';
        $parse .= ' ?>';
        return $parse;
    }

    public function tagList($tag, $content){
        if(empty($tag['table'])){$tag['table']='link';}// 表名
        if(empty($tag['where'])){$tag['where']='';}// 查询条件
        if(empty($tag['order'])){$tag['order']='';}// 排序
        if(empty($tag['id'])){ $tag['id']='vo';}// 解析数组名
        if(empty($tag['key'])){$tag['key']='k';}// 解析key名
        if(empty($tag['limit'])){$tag['limit']='10';}// 分页条数 无论是否分页的条数
        if(empty($tag['page'])){$tag['page']='false';}// 是否分页false/true
        if(empty($tag['cid'])){$tag['cid']='0'; }// 上级ID
        if(empty($tag['field'])){$tag['field']='*'; }// 上级ID
        if(empty($tag['hcsj'])){$tag['hcsj']='0'; }// 上级ID

        $parse = '<?php ';
        $parse .= '$__cid__ = ' . $tag['cid'] . ';';
        $parse .= '$__TAG__ = \'' . json_encode($tag) . '\';';
        $parse .= '$sq_db_info = model("Admin")->getlist($__TAG__,$__cid__);';
        # 开启分页
        if ($tag['page']) {
            $parse .= '$sq_page = $sq_db_info->render();';
        } else {
            $parse . '$sq_db_info';
        }
        $parse .= ' ?>';
        # 开启循环
        $parse .= '{volist name="sq_db_info" id="'.$tag['id'].'" key="'.$tag['key'].'"}';
        $parse .= $content;
        $parse .= '{/volist}';
        return $parse;

    }



    /*【栏目页不能使用 原因是需要动态栏目id】*/
    //方法 方法前加tag 方法第一个字母大写
    ///*2019/11/29更新为首页专用*/
    //方法 方法前加tag 方法第一个字母大写



}
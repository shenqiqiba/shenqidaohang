CREATE TABLE IF NOT EXISTS `sq_admin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sqname` varchar(50) DEFAULT NULL,
  `sqmima` varchar(64) DEFAULT NULL,
  `status` tinyint(3) NOT NULL DEFAULT '1' COMMENT '1正常',
  `addtime` int(11) NOT NULL DEFAULT '1578297939',
  PRIMARY KEY (`id`),
  KEY `sqname` (`sqname`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='后台';
INSERT INTO `sq_admin` VALUES (1,'admin','e10adc3949ba59abbe56e057f20f883e',1,1578297939);
CREATE TABLE IF NOT EXISTS `sq_article` (
  `aid` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(100) DEFAULT NULL,
  `keywords` varchar(255) DEFAULT NULL,
  `text` varchar(255) DEFAULT NULL COMMENT '介绍',
  `content` longtext,
  `hit` int(11) NOT NULL DEFAULT '0',
  `zan` int(11) NOT NULL DEFAULT '0',
  `addtime` int(11) DEFAULT NULL,
  `tname` varchar(30) DEFAULT NULL COMMENT '别名',
  `top` tinyint(3) NOT NULL DEFAULT '0' COMMENT '0不推荐 1推荐',
  `status` tinyint(3) NOT NULL DEFAULT '1' COMMENT '1正常 0未审核',
  `username` varchar(255) DEFAULT NULL COMMENT '发布人',
  `cid` int(11) NOT NULL DEFAULT '0',
  `link` varchar(255) DEFAULT NULL COMMENT '采集来源地址',
  PRIMARY KEY (`aid`),
  KEY `oo` (`username`,`cid`),
  KEY `title` (`title`),
  KEY `keywords` (`keywords`),
  KEY `addtime` (`addtime`),
  KEY `tname` (`tname`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
CREATE TABLE IF NOT EXISTS `sq_cata` (
  `cid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `cname` varchar(50) DEFAULT NULL,
  `keywords` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `sort` int(11) DEFAULT NULL,
  `addtime` int(11) DEFAULT NULL,
  PRIMARY KEY (`cid`),
  KEY `sort` (`sort`,`addtime`),
  KEY `name` (`name`,`cname`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
CREATE TABLE IF NOT EXISTS `sq_dianchu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `link_id` int(11) DEFAULT NULL COMMENT '点出ID',
  `time` int(11) DEFAULT NULL COMMENT '时间',
  `hit` int(11) NOT NULL DEFAULT '0' COMMENT '点出次数',
  PRIMARY KEY (`id`),
  KEY `link_id` (`link_id`,`time`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;
CREATE TABLE IF NOT EXISTS `sq_lailu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `host` varchar(100) DEFAULT NULL,
  `hit` int(11) NOT NULL DEFAULT '0' COMMENT '来源次数',
  `time` int(11) DEFAULT NULL COMMENT '最新来源时间',
  `link_id` int(11) DEFAULT NULL COMMENT '链接所属ID',
  PRIMARY KEY (`id`),
  KEY `host` (`host`,`time`,`link_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
CREATE TABLE IF NOT EXISTS `sq_link` (
  `link_id` int(11) NOT NULL AUTO_INCREMENT,
  `link_title` varchar(50) DEFAULT NULL,
  `link_keywords` varchar(255) DEFAULT NULL,
  `link_text` varchar(255) DEFAULT NULL COMMENT '描述',
  `link_url` varchar(100) DEFAULT NULL,
  `link_img` varchar(50) DEFAULT NULL,
  `link_status` tinyint(3) NOT NULL DEFAULT '1' COMMENT '1正常',
  `link_hit` int(11) NOT NULL DEFAULT '0',
  `link_addtime` int(11) NOT NULL DEFAULT '0',
  `link_sort` int(11) NOT NULL DEFAULT '0',
  `type_id` int(11) NOT NULL DEFAULT '0',
  `link_top` tinyint(3) NOT NULL DEFAULT '0' COMMENT '0不推荐 1推荐',
  `link_intime` int(11) DEFAULT NULL,
  PRIMARY KEY (`link_id`),
  KEY `link_keywords` (`link_keywords`),
  KEY `link_url` (`link_url`,`link_addtime`,`type_id`,`link_top`,`link_intime`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
CREATE TABLE IF NOT EXISTS `sq_options` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL,
  `keywords` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `status` tinyint(3) NOT NULL DEFAULT '1' COMMENT '1正常',
  `tongji` text,
  `copyright` text,
  `hcsj` int(11) NOT NULL DEFAULT '3600',
  `laiyuan` tinyint(3) NOT NULL DEFAULT '0' COMMENT '0关闭 1开启',
  `laiyuan1` tinyint(3) NOT NULL DEFAULT '0' COMMENT '0关闭 1开启 非友联来源是否统计',
  `dianchu` tinyint(3) NOT NULL DEFAULT '0' COMMENT '0关闭 1开启',
  `laiyuanshenhe` tinyint(3) NOT NULL DEFAULT '0' COMMENT '1开启',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
INSERT INTO `sq_options` VALUES (1,'神奇导航系统','http://127.0.0.3','导航,万能导航','神奇的网站',1,'','我是底部我需要自己填写',3600,1,1,1,0);
CREATE TABLE IF NOT EXISTS `sq_shoucang` (
  `uid` int(11) NOT NULL DEFAULT '0',
  `lid` text,
  `aid` text,
  PRIMARY KEY (`uid`),
  KEY `lid` (`lid`(10),`aid`(10))
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
CREATE TABLE IF NOT EXISTS `sq_type` (
  `type_id` int(11) NOT NULL AUTO_INCREMENT,
  `type_name` varchar(50) DEFAULT NULL,
  `type_keywords` varchar(255) DEFAULT NULL,
  `type_description` varchar(255) DEFAULT NULL,
  `type_status` tinyint(3) NOT NULL DEFAULT '1' COMMENT '1正常',
  `type_addtime` int(11) NOT NULL DEFAULT '0',
  `type_sort` int(11) NOT NULL DEFAULT '0',
  `type_enname` varchar(60) DEFAULT NULL,
  PRIMARY KEY (`type_id`),
  KEY `type_addtime` (`type_addtime`,`type_sort`),
  KEY `type_enname` (`type_enname`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='分类';
CREATE TABLE IF NOT EXISTS `sq_user` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) DEFAULT NULL,
  `password` varchar(64) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `qq` varchar(15) DEFAULT NULL,
  `regip` varchar(20) DEFAULT NULL,
  `loginip` varchar(20) DEFAULT NULL,
  `regtime` int(11) DEFAULT NULL,
  `jifen` int(11) NOT NULL DEFAULT '0',
  `vipendtime` int(11) NOT NULL DEFAULT '1579363200',
  `miaoshu` varchar(255) DEFAULT NULL,
  `pic` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `vipendtime` (`vipendtime`),
  KEY `username` (`username`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
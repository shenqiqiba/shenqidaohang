<?php
// +----------------------------------------------------------------------
// | ThinkPHP [ WE CAN DO IT JUST THINK ]
// +----------------------------------------------------------------------
// | Copyright (c) 2006~2018 http://thinkphp.cn All rights reserved.
// +----------------------------------------------------------------------
// | Licensed ( http://www.apache.org/licenses/LICENSE-2.0 )
// +----------------------------------------------------------------------
// | Author: liu21st <liu21st@gmail.com>
// +----------------------------------------------------------------------
Route::rule('/','index/index/index');
Route::rule('fenlei/[:tid]','Type/index')->pattern([ 'tid' => '\d+']);

Route::rule('shoulu','link/shoulu');
Route::rule('top','link/top');
Route::rule('link/:lid','link/index')->pattern(['lid' => '\d+']);
Route::rule('url/:lid','link/url')->pattern(['lid' => '\d+']);
//Route::get('cata/:cid-:page', 'cata/index');
//Route::get('cata/<cid>-<page>', 'cata/index')->name('cata');
//Route::rule('cata/[:page]','cata/index')->pattern([ 'page' => '\d+']);

Route::rule('cata/[:cid]-[:page]','/cata/index');
//Route::rule('cata/[:cid]/[:page]','cata/index')->pattern([ 'page' => '\d+']);

Route::rule('article/:aid','article/index')->pattern(['aid' => '\d+']);

Route::rule('api','api/index');
Route::rule('tags','search/tags');
Route::rule('search','search/index');


Route::rule('login', 'user/login');
Route::rule('reg', 'user/reg');
Route::rule('user', 'user/index');
Route::rule('mylink', 'user/mylink');
Route::rule('myar', 'user/myar');


Route::rule('hello/:name', 'index/hello');

return [
    '__pattern__' => [
        'name' => '\w+',
        'tid' => '\d+',
    ],

];

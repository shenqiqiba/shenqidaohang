﻿$(function(){
    $(".baidu").click(function(){
    	$(".baidu").addClass("active").siblings(".active").removeClass("active"),
    	$(".search-hidden").remove(),
    	$(".search-form").attr("action", "https://www.so.com/s"),
    	$(".search-keyword").attr({
                name: "q",
                placeholder: "360搜索"
            })
    	})
	})

$(function(){
    $(".google").click(function(){
    	$(".google").addClass("active").siblings(".active").removeClass("active"),
    	$(".search-hidden").remove(),
    	$(".search-form").attr("action", "https://www.google.com/search"),
    	$(".search-keyword").attr({
                name: "q",
                placeholder: "Google 搜索"
            })
    	})
	})

$(function(){
    $(".bing").click(function(){
    	$(".bing").addClass("active").siblings(".active").removeClass("active"),
    	$(".search-hidden").remove(),
    	$(".search-form").attr("action", "https://cn.bing.com/search"),
    	$(".search-keyword").attr({
                name: "q",
                placeholder: "微软 Bing 搜索"
            })
    	})
	})

$(function(){
    $(".torrent").click(function(){
    	$(".torrent").addClass("active").siblings(".active").removeClass("active"),
    	$(".search-hidden").remove(),
    	$(".search-form").attr("action", "https://torrentz2.eu/search"),
    	$(".search-keyword").attr({
                name: "f",
                placeholder: "磁力链，种子搜索"
            })
    	})
	})

$(function(){
    $(".scholar").click(function(){
    	$(".scholar").addClass("active").siblings(".active").removeClass("active"),
    	$(".search-hidden").remove(),
    	$(".search-form").attr("action", "https://xueshu.baidu.com/s"),
    	$(".search-keyword").attr({
                name: "wd",
                placeholder: "中英文文献检索"
            })
    	})
	})	

$(function(){
    $(".lookao").click(function(){
    	$(".lookao").addClass("active").siblings(".active").removeClass("active"),
    	$(".search-hidden").remove(),
    	$(".search-form").attr("action", "https://www.baidu.com/s"),
    	$(".search-keyword").attr({
                name: "word",
                placeholder: "百度搜索"
            })
    	})
	})

function searchon(tx){
	//this.options[this.options.selectedIndex].text;
	if(tx=="文章"){
		$("#search").attr("action", "/index.php/index/search/index");
		$("#sqkeywords").attr({
                name: "searchkeywords",
                placeholder: "本地搜索"
            });
		
	}
	if(tx=="链接"){
		$("#search").attr("action", "/index.php/index/search/index");
		$("#sqkeywords").attr({
                name: "searchkeywords",
                placeholder: "本地搜索"
            });
		
	}
	if(tx=="百度"){
		$("#search").attr("action", "https://www.baidu.com/s");
		$("#sqkeywords").attr({
                name: "word",
                placeholder: "百度搜索"
            });
		
	}
	if(tx=="谷歌"){
		$("#search").attr("action", "https://www.google.com/search");
		$("#sqkeywords").attr({
                name: "q",
                placeholder: "Google 搜索"
            });
	}
	if(tx=="必应"){
		$("#search").attr("action", "https://cn.bing.com/search");
		$("#sqkeywords").attr({
                name: "q",
                placeholder: "微软 Bing 搜索"
            });
	}
	
			
}

$(function() {
    var timeEle = document.querySelector(".indextime"),
    count = 60;
    timeEle.innerHTML = count;
    var judge = setInterval(function() {
        count--;
        if (!count) {
			clearInterval(judge);
            window.location.reload();	
        };
		if($('#sqzidong').is(':checked')==true){
			timeEle.innerHTML = count;
			}else{
				timeEle.innerHTML = 'no';
				count = 60;
			}
			
        
    }, 1000)
});




function show() {
	layui.use('layer', function(){
  var layer = layui.layer;
  
  layer.open({
        type: 1,
        title: ['【234555】福利导航|自动收录|批量检查反链 - 精品福利导航第一站'],
        area: ['980px', '300px'],
        content: '<div style="height:140px; text-align:center; background:#FFF;"><a style="display:inline-block; line-height:40px; font-size:40px; padding:25px; color:#F00; font-weight:bolder;" href="http://234555.xyz" target="_blank">http://234555.xyz</a><br/><span>（ 本站永久域名,同时请记住下面的发布页地址）</span><br><a style="display:inline-block; line-height:40px; font-size:40px; padding:25px; color:#F00; font-weight:bolder;" href="http://aoye8.com" target="_blank">http://aoye8.com</a></div>'
    });
}); 


}


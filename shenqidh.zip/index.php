<?php
/*
'软件名称：神奇导航系统
'开发作者：神奇  QQ：97302834  官方网站：http://shenqiyu.com
'--------------------------------------------------------
'这不是一个自由软件！您只能在不用于商业目的的前提下对程序代码进行修改和使用；
'不允许对程序代码以任何形式任何目的的再发布。
'--------------------------------------------------------
*/

// [ 应用入口文件 ]
namespace think;
// 检测PHP环境
if(version_compare(PHP_VERSION,'5.5.0','<'))  die('PHP版本过低，最少需要PHP5.5，请升级PHP版本！');
//超时时间
@ini_set('max_execution_time', '0');
//内存限制 取消内存限制
@ini_set("memory_limit",'-1');
if(!is_writable('./runtime')) {
    echo '请开启[runtime]文件夹的读写权限';
    exit;
}
define('APP_PATH', __DIR__ . '/application/');



define('SHOUYE_PATH', __DIR__);
// 加载基础文件
require __DIR__ . '/thinkphp/base.php';

//return $this->redirect('admin/admin/index',302);
// 执行应用并响应
Container::get('app')->path(APP_PATH)->run()->send();


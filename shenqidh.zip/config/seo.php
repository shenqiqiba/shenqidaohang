<?php /*自定义的网站配置文件*/
 return array(
'seo' =>
array (
  'typetitle' => '网址大全',
  'typekeywords' => '网址大全,导航',
  'typedescription' => '神奇导航带你浏览网址大全',
  'catatitle' => '线报大全',
  'catakeywords' => '线报,活动',
  'catadescription' => '活动线报带你一撸到底',
)); 
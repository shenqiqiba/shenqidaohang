<?php /*自定义的网站配置文件*/
 return array(
'sqsetting' =>
array (
  'cookie' => 'cookie',
  'keywords' => '哈哈,哎呀',
  'tihuanwords' => '',
  'apimima' => '123456789',
  'zuozhe' => '神奇小助手',
  'laiyuan' => '0',
)); 
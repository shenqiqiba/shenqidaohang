<?php
return [
    'sqsetting' =>[
    'name' => '神奇导航系统',
    'copyright' => '234555.xyz',
    'url' => 'http://234555.xyz/',
    'code' => '2020.01.15.1617',
    'license' => '免费版',
    've'=>'0.2',
    ],
];
